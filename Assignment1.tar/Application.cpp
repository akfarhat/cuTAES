#include <iostream>
#include <fstream>
using namespace std;

#include "Application.h"

int Application::nextAppNumber = 1;

// Constructor
Application::Application(Student* stu, string c, string rc, string we, string r) {
  applicant		= stu;                                              // applicant is a pointer
  applicationNumber 	= nextAppNumber;
  course 		= c;
  relatedCourses 	= rc;
  workExperience 	= we;
  references 		= r;
  status 		= "pending";

  cout << "Application constructor called" << endl;
}

// Destructor
Application::~Application() {
}

const void Application::printApplication() {
  if (applicant == NULL){
    return;
  }
  cout << "Application for: " << applicant->getName() << endl;              // applicant is a pointer
  cout << "Course: " << course << endl;
  cout << "Application #" << applicationNumber << endl << endl;
}

// Saves an application to a file
// Returns either ERROR or SUCCESS (preprocessor definitions)
int Application::saveApplication() {
  ofstream outFile("applications.txt", ios::out);

  if (!outFile){
    return ERROR;                                                 // Error is a preprocessor definition. Value is 0
  }

  string delimiter = "\n";                                                                         // Seperates the text by a delimiter (in this case, new lines)
  outFile << applicationNumber++ << delimiter << course << delimiter << relatedCourses;            // Outputs the application information to a file
  outFile << delimiter << workExperience << delimiter << references << delimiter;          
  outFile << applicant->getStuNum();

  outFile.close();

  return SUCCESS;                                                  // Success is a preprocessor definition. Value is 1
}
