#ifndef APP_H
#define APP_H

#include "Student.h"

class Application {

  friend class Student;
  
  static int nextAppNumber;

  public:
    // Applicant, application number, course, related courses, work experience, references
    Application(Student* = NULL, string = "0", string = "0", string = "0", string = "0");
    ~Application();
    const void printApplication();
    int saveApplication();

  private:
    int applicationNumber; 
    Student* applicant;
    string course;
    string relatedCourses;
    string workExperience;
    string references;
    string status;
};

#endif
