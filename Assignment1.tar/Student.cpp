#include <iostream>
using namespace std;

#include "Student.h"
#include "Application.h"

// Constructor (will change to constructor initializer syntax if needed)
Student::Student(string stu, string fn, string ln, string em, string maj, int year, float CG, float MG) {
  studentNumber 	= stu;
  firstName 		= fn;
  lastName 		= ln;
  email 		= em;
  major 		= maj;
  yearStanding 		= year;
  CGPA 			= CG;
  MGPA 			= MG;

  cout << "Student constructor called" << endl;
}

// Destructor
Student::~Student() {
}

// Getters
const string Student::getName(){
  return firstName + " " + lastName;
}

const string Student::getStuNum(){
  return studentNumber;
}

// Prints the student's information
void Student::printStudent(){
  cout << "Student: " << firstName << " " << lastName << endl;
  cout << "Student number: " << studentNumber << endl;
  cout << "Student email: " << email << endl;
  cout << "Student major: " << major << endl;
  cout << "Student in year: " << yearStanding << " with CGPA: " << CGPA << " and major GPA: " << MGPA << endl << endl; 
}


// Create an application if the user submits one
// Parameters are: the student, the course, the related courses, the work experience and the references
// Returns value from saveApplication, ERROR or SUCCESS
int Student::applyConfirmed(string c, string rc, string we, string r){                   
  Application newApp(this, c, rc, we, r);
  return newApp.saveApplication();
}


