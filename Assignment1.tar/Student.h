#ifndef STUDENT_H
#define STUDENT_H

#define ERROR 0
#define SUCCESS 1

class Student {

// Student information: student number, first and last names, email address, major, year standing, CGPA, and major GPA
  public:
    Student(string = "0", string = "0", string = "0", string = "0", string = "0", int = -1, float = -1.0, float = -1.0);
    ~Student();
    void printStudent();
    const string getName();
    const string getStuNum();
    int applyConfirmed(string, string, string, string);   // They confirm a submission of an application

  private:
    string studentNumber;
    string firstName;
    string lastName;
    string email;
    string major;
    int yearStanding;
    float CGPA;
    float MGPA;
};

#endif 
