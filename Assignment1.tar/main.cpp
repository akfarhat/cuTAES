#include <iostream>
using namespace std;

#include "Student.h"
#include "Application.h"

int main(){
  // Use of functions:

  Student stu2("100860640", "Andrew", "Belu", "ab@hotmail.com", "Comp Sci", 2, 12.00, 12.00); // Constructs a student
  stu2.printStudent();          // Prints the student information (debugging purposes?)

  Application app2(&stu2, "COMP2402", "COMP1805", "TA experience", "John Doe"); // Constructs an application

  app2.printApplication(); // Prints the application information (debugging purposes?)

  // This constructs an application and saves it's information to a file. I am not sure how GTK works but you may be able to input the information directly into here
  // from the text fields after the confirm button is pressed.
  stu2.applyConfirmed("100860640", "Applying for: COMP1805", "Related Courses: COMP1405, COMP1406, COMP2402", "Work experience: I have 2 years of software engineering experience, working in an object oriented context and yada yada yada....");    
 

  return 0;
}
